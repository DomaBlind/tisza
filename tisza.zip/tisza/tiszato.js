function turizmus(melyik){
    var img = document.createElement("img");
    img.src = "kepek/" + param + ".jpg";
    document.getElementById("image-container").appendChild(img);  
    document.getElementById('turizmusszovegkeret').style.display='none';
    document.getElementById('turizmuskep').src=melyik+'.jpg';
    document.getElementById('turizmuskepkeret').style.display='block';
}

function keprejt(melyik){
  document.getElementById('turizmuskepkeret').style.display='none';
  document.getElementById('turizmusszovegkeret').style.display='block';
  document.getElementById("image-container").style.display = "none";
}

document.querySelectorAll(".tourism td").forEach(item => {
    item.addEventListener("mouseleave", keprejt);
});